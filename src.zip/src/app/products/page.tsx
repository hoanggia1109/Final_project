'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';

interface Product {
  id: number;
  tensp: string;
  thumbnail: string;
  mota: string;
  slug: string;
  hot: number;
  anhien: number;
  code: string;
}

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://localhost:3001/api/sanpham') // 👉 đổi lại URL API backend thật của bạn
      .then((res) => res.json())
      .then((data) => {
        setProducts(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Lỗi khi tải sản phẩm:', err);
        setLoading(false);
      });
  }, []);

  if (loading)
    return (
      <div className="text-center py-5">
        <div className="spinner-border text-warning"></div>
      </div>
    );

  return (
    <>
      <style jsx global>{`
        .product-card {
          transition: all 0.3s ease;
          border-radius: 12px;
          overflow: hidden;
        }
        .product-card:hover {
          transform: translateY(-8px);
          box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
        }
        .product-image {
          position: relative;
          width: 100%;
          height: 260px;
        }
        .product-info {
          padding: 15px;
          text-align: center;
        }
        .product-title {
          font-size: 1rem;
          font-weight: 600;
          color: #333;
          margin-bottom: 8px;
          transition: color 0.3s ease;
        }
        .product-title:hover {
          color: #FFC107;
        }
        .product-desc {
          font-size: 0.9rem;
          color: #777;
          min-height: 45px;
        }
      `}</style>

      <section className="py-5 bg-light">
        <div className="container">
          <h2 className="text-uppercase fw-bold mb-4 text-center">
            TẤT CẢ SẢN PHẨM
          </h2>

          <div className="row g-4">
            {products.map((item) => (
              <div key={item.id} className="col-6 col-md-4 col-lg-3">
                <Link href={`/products/${item.id}`} className="text-decoration-none">
                  <div className="card border-0 shadow-sm product-card bg-white">
                    <div className="product-image">
                      <Image
                        src={item.thumbnail}
                        alt={item.tensp}
                        fill
                        style={{ objectFit: 'cover' }}
                      />
                    </div>
                    <div className="product-info">
                      <h5 className="product-title">{item.tensp}</h5>
                      <p className="product-desc text-muted">{item.mota?.slice(0, 50)}...</p>
                      <span
                        className={`badge ${
                          item.anhien ? 'bg-success' : 'bg-secondary'
                        }`}
                      >
                        {item.anhien ? 'Hiển thị' : 'Ẩn'}
                      </span>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
