import HomePage from "./component/HomePage";

export default function Home() {
  return <HomePage />;
}
