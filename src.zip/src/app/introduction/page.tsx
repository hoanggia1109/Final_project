import IntroductionPage from '../component/IntroductionPage';

export default function Introduction() {
  return <IntroductionPage />;
}

