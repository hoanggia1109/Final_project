# QUICK TEST - Email Cập nhật Trạng thái Đơn hàng

## 🚀 Test nhanh bằng Swagger

### Bước 1: Mở Swagger UI
```
http://localhost:5001/api-docs
```

### Bước 2: Đăng nhập để lấy token

1. Tìm endpoint: **POST `/api/auth/dangnhap`**
2. Click **"Try it out"**
3. Nhập thông tin:
   ```json
   {
     "email": "admin@admin.com",
     "password": "admin123"
   }
   ```
4. Click **"Execute"**
5. Copy **token** từ response

### Bước 3: Authorize

1. Click nút **"Authorize"** (🔓) ở góc trên
2. Nhập: `Bearer YOUR_TOKEN_HERE`
3. Click **"Authorize"** và **"Close"**

### Bước 4: Lấy danh sách đơn hàng

1. Tìm endpoint: **GET `/api/admin/donhang`**
2. Click **"Try it out"** → **"Execute"**
3. Copy một `id` đơn hàng từ response

### Bước 5: Cập nhật trạng thái đơn hàng

1. Tìm endpoint: **PUT `/api/admin/donhang/{id}`**
2. Click **"Try it out"**
3. Nhập `id` đơn hàng vào path parameter
4. Body (Request body):
   ```json
   {
     "trangthai": "confirmed"
   }
   ```
5. Click **"Execute"**

### Bước 6: Kiểm tra

- ✅ Response: `{"message": "Cập nhật trạng thái đơn hàng thành công"}`
- ✅ Console server: `Order status update email sent to ...`
- ✅ Email đến inbox của customer

---

## 🧪 Test bằng cURL

```bash
# 1. Đăng nhập admin
TOKEN=$(curl -s -X POST http://localhost:5001/api/auth/dangnhap \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@admin.com","password":"admin123"}' \
  | grep -o '"token":"[^"]*' | cut -d'"' -f4)

echo "Token: $TOKEN"

# 2. Lấy danh sách đơn hàng
curl -X GET http://localhost:5001/api/admin/donhang \
  -H "Authorization: Bearer $TOKEN"

# 3. Cập nhật trạng thái (thay ORDER_ID bằng id thực tế)
curl -X PUT http://localhost:5001/api/admin/donhang/ORDER_ID \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"trangthai":"confirmed"}'
```

---

## 📧 Test bằng Script

```bash
cd server_node

# Test với dữ liệu mẫu
node scripts/test-order-status-email.js OD1234567890 confirmed your-email@gmail.com
```

---

## ✅ Kỳ vọng

1. **Server response:** `{"message": "Cập nhật trạng thái đơn hàng thành công"}`
2. **Console log:** `Order status update email sent to customer@email.com`
3. **Email nhận được:** Subject có dạng `Cập nhật trạng thái đơn hàng #OD...`

---

**Lưu ý:** Đảm bảo đã cấu hình EMAIL_USER và EMAIL_PASSWORD trong `.env`!

