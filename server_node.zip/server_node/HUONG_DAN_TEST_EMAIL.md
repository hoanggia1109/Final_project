# HƯỚNG DẪN TEST TÍNH NĂNG GỬI EMAIL CẬP NHẬT TRẠNG THÁI ĐƠN HÀNG

## 📋 Tổng quan

Tính năng gửi email sẽ tự động gửi email cho khách hàng khi:
1. Admin cập nhật trạng thái đơn hàng
2. User hủy đơn hàng

## ✅ Chuẩn bị

### 1. Kiểm tra cấu hình Email trong `.env`

Đảm bảo các biến sau đã được cấu hình đúng:

```env
EMAIL_SERVICE=gmail
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password
EMAIL_FROM=your-email@gmail.com
```

**Lưu ý:** Để test email, bạn cần:
- Email Gmail hợp lệ
- App Password từ Google Account (không phải password thường)

### 2. Kiểm tra server đang chạy

```bash
cd server_node
npm run dev
```

Server phải chạy thành công tại `http://localhost:5001`

## 🧪 CÁCH 1: Test bằng API trực tiếp

### Test 1: Admin cập nhật trạng thái đơn hàng

**Bước 1:** Lấy token admin
```bash
# Đăng nhập admin
curl -X POST http://localhost:5001/api/auth/dangnhap \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@admin.com",
    "password": "admin123"
  }'
```

Lưu token từ response.

**Bước 2:** Lấy danh sách đơn hàng
```bash
# Lấy danh sách đơn hàng (cần token admin)
curl -X GET http://localhost:5001/api/admin/donhang \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
```

Chọn một `id` đơn hàng để test.

**Bước 3:** Cập nhật trạng thái đơn hàng
```bash
# Cập nhật trạng thái từ "pending" -> "confirmed"
curl -X PUT http://localhost:5001/api/admin/donhang/ORDER_ID \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "trangthai": "confirmed"
  }'
```

**Kỳ vọng:**
- Response: `{"message": "Cập nhật trạng thái đơn hàng thành công"}`
- Trong console server: `Order status update email sent to ...`
- Email được gửi đến email của customer

### Test 2: User hủy đơn hàng

**Bước 1:** Lấy token user
```bash
# Đăng nhập user
curl -X POST http://localhost:5001/api/auth/dangnhap \
  -H "Content-Type: application/json" \
  -d '{
    "email": "customer@test.com",
    "password": "123456"
  }'
```

**Bước 2:** Hủy đơn hàng
```bash
# Hủy đơn hàng (cần token user)
curl -X PUT http://localhost:5001/api/donhang/ORDER_ID/huy \
  -H "Authorization: Bearer YOUR_USER_TOKEN"
```

**Kỳ vọng:**
- Response: `{"message": "Đã hủy đơn hàng"}`
- Email thông báo hủy đơn được gửi

## 🌐 CÁCH 2: Test bằng Swagger UI

1. Mở Swagger UI: `http://localhost:5001/api-docs`

2. Đăng nhập để lấy token:
   - POST `/api/auth/dangnhap`
   - Copy token từ response

3. Authorize trong Swagger:
   - Click nút **"Authorize"** ở góc trên
   - Nhập: `Bearer YOUR_TOKEN`
   - Click **"Authorize"**

4. Test API cập nhật đơn hàng:
   - Tìm endpoint: `PUT /api/admin/donhang/{id}`
   - Click **"Try it out"**
   - Nhập `id` đơn hàng
   - Body:
     ```json
     {
       "trangthai": "confirmed"
     }
     ```
   - Click **"Execute"**
   - Kiểm tra response và console server

## 📧 CÁCH 3: Test bằng script Node.js

Tạo file test script:

```bash
cd server_node
node scripts/test-order-status-email.js
```

## 🔍 Kiểm tra kết quả

### 1. Kiểm tra Console Server

Khi email được gửi thành công, bạn sẽ thấy trong console:
```
Order status update email sent to customer@email.com - Order: OD1234567890, Status: pending -> confirmed
```

Nếu có lỗi:
```
Error sending order status update email: [chi tiết lỗi]
```

### 2. Kiểm tra Email Inbox

Mở hộp thư của customer và tìm email với:
- **Subject:** `Cập nhật trạng thái đơn hàng #OD1234567890 - Đã xác nhận`
- **From:** `Shop Nội Thất <your-email@gmail.com>`

### 3. Các trạng thái có thể test

| Trạng thái | Tiêu đề Email | Màu sắc |
|------------|---------------|---------|
| `confirmed` | Đã xác nhận | Xanh dương |
| `shipping` | Đang giao hàng | Xanh dương |
| `delivered` | Đã giao hàng | Xanh lá |
| `cancelled` | Đã hủy | Đỏ |
| `returned` | Đã trả hàng | Xám |

## 🐛 Troubleshooting

### Lỗi: "Error sending order status update email"

**Nguyên nhân có thể:**
1. Email config sai trong `.env`
2. App Password không đúng
3. Gmail chặn ứng dụng không an toàn

**Giải pháp:**
- Kiểm tra lại `.env` file
- Tạo lại App Password từ Google Account
- Bật "Allow less secure apps" (nếu dùng password thường)

### Lỗi: "Cannot read property 'email' of undefined"

**Nguyên nhân:** Đơn hàng không có user hoặc user không có email

**Giải pháp:** Kiểm tra đơn hàng có user_id hợp lệ không

### Không nhận được email

1. Kiểm tra **Spam/Junk** folder
2. Kiểm tra console server có log lỗi không
3. Kiểm tra email config có đúng không
4. Test với email khác

## 📝 Checklist test

- [ ] Server đang chạy
- [ ] Email config đúng trong `.env`
- [ ] Có đơn hàng để test
- [ ] Có token admin/user
- [ ] Test cập nhật trạng thái: pending → confirmed
- [ ] Test cập nhật trạng thái: confirmed → shipping
- [ ] Test cập nhật trạng thái: shipping → delivered
- [ ] Test hủy đơn hàng
- [ ] Kiểm tra email nhận được
- [ ] Kiểm tra nội dung email đúng

---

**Lưu ý:** Trong môi trường development, email sẽ được gửi thật. Nên test với email test hoặc email của bạn.

